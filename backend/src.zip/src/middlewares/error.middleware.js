
import AppError from "../utils/AppError.js";

export default (err, req, res, next) => {
  if (!err.isOperational) {
    console.error("UNEXPECTED ERROR:", err);
  }

  const statusCode = err.statusCode || 500;

  res.status(statusCode).json({
    status: err.status || "error",
    message: err.message || "Internal Server Error",
  });
};

export const globalErrorHandler = (err, req, res, next) => {
  console.error(err);

  res.status(500).json({
    status: "error",
    message: err.message || "Internal server error",
  });
};
