import express from "express";
import cors from "cors"; 
import authRoutes from "./modules/auth/auth.routes.js";
import jobRoutes from "./jobs/job.routes.js";
import { globalErrorHandler } from "./middlewares/error.middleware.js";
import swaggerUi from "swagger-ui-express";
import { swaggerSpec } from "./config/swagger.js";



const app = express();

app.use(express.json());

app.use(cors({
  origin: 'https://job-application-tracker-v1.vercel.app', 
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true
}));


app.use("/api/auth", authRoutes);
app.use("/api/jobs", jobRoutes);
app.use(globalErrorHandler);
app.use("/api/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));


export default app;