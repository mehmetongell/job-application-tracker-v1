import { z } from "zod";

export const createJobSchema = z.object({
  company: z.string().min(2),
  position: z.string().min(2),
  location: z.string().optional(),
  status: z.enum(["APPLIED", "INTERVIEW", "OFFER", "REJECTED"]).optional(),
});

export const updateJobStatusSchema = z.object({
  status: z.enum(["APPLIED", "INTERVIEW", "OFFER", "REJECTED"]),
});
