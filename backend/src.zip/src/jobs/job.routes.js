import { Router } from "express";
import authMiddleware from "../middlewares/auth.middleware.js";
import validate from "../middlewares/validate.middleware.js";
import {
  create,
  list,
  getOne,
  updateStatus,
  remove,
} from "./job.controller.js";
import {
  createJobSchema,
  updateStatusSchema,
} from "./job.validation.js";

const router = Router();

/**
 * @swagger
 * tags:
 *   name: Jobs
 *   description: Job application management
 */

router.use(authMiddleware);

/**
 * @swagger
 * /api/jobs:
 *   post:
 *     summary: Create a new job application
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateJob'
 *     responses:
 *       201:
 *         description: Job created successfully
 */
router.post("/", validate(createJobSchema), create);

/**
 * @swagger
 * /api/jobs:
 *   get:
 *     summary: Get all job applications for logged-in user
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of jobs
 */
router.get("/", list);

/**
 * @swagger
 * /api/jobs/{id}:
 *   get:
 *     summary: Get a single job application
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Job found
 *       404:
 *         description: Job not found
 */
router.get("/:id", getOne);

/**
 * @swagger
 * /api/jobs/{id}/status:
 *   patch:
 *     summary: Update job status
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateJobStatus'
 *     responses:
 *       200:
 *         description: Job status updated
 */
router.patch("/:id/status", validate(updateStatusSchema), updateStatus);

/**
 * @swagger
 * /api/jobs/{id}:
 *   delete:
 *     summary: Delete a job application
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       204:
 *         description: Job deleted successfully
 */
router.delete("/:id", remove);

export default router;
