import { asyncHandler } from "../utils/asyncHandler.js";
import {
  createJob,
  getJobs,
  getJobById,
  updateJobStatus,
  deleteJob,
} from "./job.service.js";

export const create = asyncHandler(async (req, res) => {
  const job = await createJob(req.user.id, req.body);

  res.status(201).json({
    status: "success",
    data: job,
  });
});

export const list = asyncHandler(async (req, res) => {
  const result = await getJobs(req.user.id, req.query);

  res.json({
    status: "success",
    ...result,
  });
});


export const getOne = asyncHandler(async (req, res) => {
  const job = await getJobById(req.params.id, req.user.id);

  res.json({
    status: "success",
    data: job,
  });
});

export const updateStatus = asyncHandler(async (req, res) => {
  const job = await updateJobStatus(
    req.params.id,
    req.user.id,
    req.body.status
  );

  res.json({
    status: "success",
    data: job,
  });
});

export const remove = asyncHandler(async (req, res) => {
  await deleteJob(req.params.id, req.user.id);
  res.status(204).send();
});
