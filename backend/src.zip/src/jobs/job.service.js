import prisma from "../prisma/client.js";
import AppError from "../utils/AppError.js";

export const createJob = async (userId, data) => {
  return prisma.jobApplication.create({
    data: {
      ...data,
      userId,
    },
  });
};

export const getJobs = async (userId) => {
  return prisma.jobApplication.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });
};

export const updateJobStatus = async (jobId, userId, status) => {
  const job = await prisma.jobApplication.findFirst({
    where: { id: jobId, userId },
  });

  if (!job) {
    throw new AppError("Job not found", 404);
  }

  return prisma.jobApplication.update({
    where: { id: jobId },
    data: { status },
  });
};
